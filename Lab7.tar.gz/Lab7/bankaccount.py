class BankAccount:
    def __init__(self,anum=000000,anam="",bal=0):
        self._accountNumber=0000000
        self._accountName=""
        self._balance=0
        self._rate=0.08
    def setaccountNumber(self,Number):
        self._accountNumber=Number
    def setaccountName(self,Name):
        self._accountName=Name
    def setbalance(self,accountbalance):
        self._balance=accountbalance
    def setrate(self,newrate):
        self._rate=newrate
    def getaccountNumber(self):
        return self._accountNumber
    def getaccountName(self):
        return self._accountName
    def getbalance(self):
        return self._balance
    def getrate(self):
        return self._rate
    def deposit(self,dep):
      self._balance += dep
    def withdrawal(self,withd):
      self._balance -= withd
    def __str__(self):
        return "Your account number is",self._accountNumber,"\n","Your account name is",self._accountName,"\n","and your balance is",self._balance
    def __add__(self,otheraccount):
        total=self._balance+otheraccount.balance#this refers to the "this" object the bank2 object is the one being passed through
    def __lt__(self,otheraccount):   #less than statement, gt is greater than statement
        if self._balance<otheraccount:
            return True
        else:
            return False
    def addInterest(self):
        self._balance+=self._balance*self._rate
        
