from bankaccount import *
while num!=0:
    num=int(raw_input('What is account number? Enter 0 to stop:'))
    name=raw_input('Enter Name:')
    try:
        bal=float(raw_input('Enter balance up to second decimal place:'))
    except ValueError:
        print "You must enter a balance"
    bo=BankAccount(num1,name,bal)
    banklist=[]
    banklist.append(bo)
for i in range(len(banklist)):
    banklist[i].setrate=.03
    print banklist[i].getaccountNumber
    print banklist[i].getaccountName
    print banklist[i].getbalance
for i in range(len(banklist)):
    small=banklist[i].getbalance
    if small>banklist[i+1].getbalance:
        small=banklist[i+1].getbalance
print small
    
    
    
